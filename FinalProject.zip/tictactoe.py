import pygame
from StartScreen import StartScreen

pygame.init()
s = StartScreen()
s.init()
